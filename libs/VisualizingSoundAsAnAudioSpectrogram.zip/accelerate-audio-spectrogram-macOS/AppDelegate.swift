/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app delegate.
*/

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    @IBOutlet var window: NSWindow!
}

